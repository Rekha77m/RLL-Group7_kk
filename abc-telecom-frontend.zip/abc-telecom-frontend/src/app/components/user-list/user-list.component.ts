import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Customer } from 'src/app/common/customer';
import { Engineer } from 'src/app/common/engineer';
import { Manager } from 'src/app/common/manager';
import { LoginService } from 'src/app/services/login.service';
import { UserService } from 'src/app/services/user.service';
import { User } from 'c:/Users/Admin/Desktop/RLL/New folder/abc-telecom-frontend/src/app/common/user';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit {

  // loggedInUser:User=null;

  customers:Customer[]=[];
  engineers:Engineer[]=[];
  managers:Manager[]=[];
  role:string='';
  router: any;
  loggedInUser: User;
  constructor(private userService:UserService, private loginService:LoginService,private route:ActivatedRoute) { }


  ngOnInit(): void {
    if(this.loginService.loggedInUser!=null){
      this.loginService.loggedInUser.subscribe(data=>{
        this.loggedInUser=data;
      })
    }
    if(this.loginService.loggedInUser==null){
      this.router.navigateByUrl('login');
    }

    this.route.paramMap.subscribe(()=>{
      this.loadusers();
    })
   
  }
  loadusers() {
    if(this.route.snapshot.paramMap.has('role')){
      this.role = this.route.snapshot.paramMap.get('role');

      if(this.role=='customer'){

        this.userService.getCustomers().subscribe(data=>[
          this.customers=data
        ]);
      }

      if(this.role=='engineer'){
        this.userService.getEngineers().subscribe(data=>{
          this.engineers=data;
        });
      }
      if(this.role=='manager'){
        this.userService.getManagers().subscribe(data=>{
          this.managers=data;
        });

      }
    }
  }

  deleteUser(id:number,customer){
   this.userService.deleteCustomer(id).subscribe(data=>{
      alert(`User ${data} has been deleted successfully`)
      this.loadusers();

    });
    
  }
  deleteUser1(id:number,manager){
    this.userService.deletemanager(id).subscribe(data=>{
       alert(`User ${data} has been deleted successfully`)
       this.loadusers();
 
     });
    }
    deleteUser2(id:number,engineer){
      this.userService.deleteengineer(id).subscribe(data=>{
         alert(`User ${data} has been deleted successfully`)
         this.loadusers();
   
       });
      }
}
